import numpy as np
import matplotlib.pyplot as plt

ne = 100
nz = 540
ef = -1.513
d = 3
data = np.zeros((3,ne,nz))
for ie in range(ne):
    fname = "LDOSMAG.R"+str(d)+"."+str(ie+1).zfill(4)+".dat"
    with open(fname, 'r') as f:
        text = f.readlines()
    # number of lines
    nlin=len(text)
    for il in range(nlin):
        text[il] = text[il].split()
        data[0,ie,il] = float(text[il][0])
        data[1,ie,il] = float(text[il][1])-ef
        data[2,ie,il] = np.log10(max(float(text[il][2]),0.0000000001))

# shift data
data[2] = np.roll(data[2],20,axis = 1)

# Plot
cm = "hot"
fig, ax = plt.subplots(figsize = (12,6))

vmin = -4
vmax = -2
bc=ax.pcolormesh(data[0],data[1],data[2],cmap=cm,vmin=vmin, vmax=vmax)
cbar=plt.colorbar(bc,ticks=[vmin,vmax], shrink=0.7)
cbar.ax.set_yticklabels([vmin,vmax],size=20)
cbar.ax.set_ylabel(r"$\log(LDOS)$", rotation=270,size=20)

ax.set_xticks([])
ax.set_yticklabels([-3,-2,-1,0,1,2],size=20)
ax.set_ylabel(r'$E-E_{\mathrm{F}}$ (eV)',size=20)

# export
fig.tight_layout()
#plt.show()
fig.savefig("ldosmag.png")
